﻿using System.ComponentModel.DataAnnotations;

namespace mvcProject1.Models
{
    public class SalaryInfo
    {

        public int SalaryId { get; set; } //primarykey
        public int EmployeeId { get; set; } //foreignkey

        public decimal Net { get; set; }
        public decimal Gross { get; set; }

        public Employee Employee { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using mvcProject1.Models;

namespace mvcProject1.Controllers
{
    public class CompanyController : Controller
    {
        private readonly EmployeeContext _context;

        public CompanyController(EmployeeContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var companyDetails = _context.Companies
                .Select(c => new CompanyDetailsDto
                {
                    Id = c.Id,
                    Name = c.Name,
                    FullAddress = $"{c.Address}, {c.City}, {c.Country}",
                    NumberOfEmployees = _context.Employees.Count(e => e.CompanyId == c.Id)
                })
                .ToList();

            return View(companyDetails);
        }
    }
}

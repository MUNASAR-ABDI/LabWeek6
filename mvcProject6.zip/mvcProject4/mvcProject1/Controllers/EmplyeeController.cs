﻿using Microsoft.AspNetCore.Mvc;
using mvcProject1.Models;

namespace mvcProject1.Controllers
{
    public class EmployeeController : Controller
    {
        List<Employee> EmployeeS = new List<Employee>();
        public EmployeeController()
        {
            EmployeeS = new List<Employee>
            {
                new Employee
                {
                    Id = 1, Name = "Martin", Surname = "Simpson",
                    BirthDate = new DateTime(1992, 12, 3),
                    Position = "Marketing Expert", Image="/images/Martin.jpg"
                },
                new Employee
                {
                    Id = 2, Name = "Jacob", Surname = "Hawk",
                    BirthDate = new DateTime(1995, 10, 2), Position = "Manager", Image="/images/Jacob.jpg"
                },
                new Employee
                {
                    Id = 3, Name = "Elizabeth", Surname = "Geil",
                    BirthDate = new DateTime(2000, 1, 7),
                    Position = "Software Engineer", Image="/images/Elizabeth.jpg"
                },
                new Employee
                {
                    Id = 4, Name = "Kate", Surname =  "Metain",
                    BirthDate = new DateTime(1997, 2, 13),
                    Position = "Admin", Image="/images/Kate.jpg"
                },
                new Employee
                {
                    Id = 5, Name = "Michael", Surname = "Cook",
                    BirthDate = new DateTime(1990, 12, 25),
                    Position = "Marketing expert", Image="/images/Michael.jpg"
                },
                new Employee
                {
                    Id = 6, Name = "John", Surname = "Snow",
                    BirthDate = new DateTime(2001, 7, 15),
                    Position = "Software Engineer", Image="/images/John.jpg"
                },
                new Employee
                {
                    Id = 7, Name = "Nina", Surname = "Soprano",
                    BirthDate = new DateTime(1999, 9, 30),
                    Position = "Software Engineer", Image="/images/Nina.jpg"
                },
                new Employee
                {
                    Id = 8, Name = "Tina", Surname = "Fins",
                    BirthDate = new DateTime(2000, 5, 14),
                    Position = "Team Leader", Image="/images/Tina.jpg"
                }
            };
        }

        public IActionResult Index()
        {
            ViewBag.Layout = "_Lab2Layout";
            return View(EmployeeS);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details(int id = 1)
        {
            var employee = EmployeeS.FirstOrDefault(m => m.Id == id);
            return View(employee);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var employee = EmployeeS.FirstOrDefault(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        public IActionResult Edit(int id, [Bind("Name,Surname,Position")] Employee employee)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingEmployee = EmployeeS.FirstOrDefault(m => m.Id == id);
                if (existingEmployee != null)
                {
                    existingEmployee.Name = employee.Name;
                    existingEmployee.Surname = employee.Surname;
                    existingEmployee.Position = employee.Position;
                }
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            var employee = EmployeeS.FirstOrDefault(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        public IActionResult Update(int id, [Bind("Name,Surname,Position")] Employee employee)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingEmployee = EmployeeS.FirstOrDefault(m => m.Id == id);
                if (existingEmployee != null)
                {
                    existingEmployee.Name = employee.Name;
                    existingEmployee.Surname = employee.Surname;
                    existingEmployee.Position = employee.Position;
                }
                return RedirectToAction("Index");
            }
            return View(employee);
        }
        public IActionResult SalaryDetails(int id)
        {
            // Query the EmployeeS list and project the data into EmployeeSalaryDto objects
            var model = EmployeeS.Where(e => e.Id == id)
                                 .Select(e => new EmployeeSalaryDto
                                 {
                                     Id = e.Id,
                                     FullName = e.Name + " " + e.Surname, // You can use any logic to construct the full name
                                     CompanyName = "ABC Inc.", // You can use any logic to assign the company name
                                     GrossSalary = e.salary, // You can use any logic to calculate the gross salary
                                     NetSalary = e.salary * 0.8m - 100 // You can use any logic to calculate the net salary
                                 })
                                 .ToList();
            return View(model);
        }
    }
}
